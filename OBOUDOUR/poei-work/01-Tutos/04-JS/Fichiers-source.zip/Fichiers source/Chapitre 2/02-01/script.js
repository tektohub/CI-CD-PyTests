// Execution 1
// Le navigateur va alerter le nombre 10
var score  = 10;
alert(score);

// Execution 2
// Le navigateur va alerter le nombre 10, et lorsque vous cliquer sur OK,
// le navigateur va alerter 100.
var score  = 10;
alert(score);

score = 100;
alert(score);

// Execution 3
// Nous obtenons un message d'erreur ici,
// car "score" avec "s" minuscule en ligne 1
// est différente de "Score" avec "s" majuscule en ligne 2
var score  = 10;
alert(Score);

score = 100;
alert(score);


// Execution 4
var phrase = "Bonjour tout le monde!";
alert(phrase);