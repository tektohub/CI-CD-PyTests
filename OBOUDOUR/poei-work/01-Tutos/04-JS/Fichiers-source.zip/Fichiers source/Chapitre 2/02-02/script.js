// execution 1
// "prompt" ouvre une boîte de dialogue où le visiteur peut taper sa réponse,
// mais de cette façons la réponse entrer par l'utilisateur et inutile,
// car on ne pas acceder à elle.
prompt("Comment vous appelez-vous?");


// execution 2
// Ligne 1 affiche une boîte de dialogue prompte,
// puis conserve la valeur entré par l'utilisateur dans la variable "nom",
// puis la fonction "alert" affiche le contenu de cette variable.
var nom = prompt("Comment vous appelez-vous?");
alert(nom);

