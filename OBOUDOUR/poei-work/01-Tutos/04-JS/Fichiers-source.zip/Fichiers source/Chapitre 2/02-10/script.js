//Ceci est un commentaire qui est ignoré par le moteur JavaScript

var prenom = "François"; // Ceci stocke un prénom 

/* Ceci est un commentaire qui couvre plusieurs lignes,
    il utilise la même syntaxe que le CSS
/*

