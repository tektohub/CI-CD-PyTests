// Execution 1
// Un initialisateur d'objet est une liste contenant plusieurs (éventuellement 0) propriétés, 
// séparées par des virgules, et leurs valeurs associées,cette liste étant entourée d'accolades ({}).
var personne = {
    nom_complet: "William Fontaine",
    age: 32,
    administrateur: false
};