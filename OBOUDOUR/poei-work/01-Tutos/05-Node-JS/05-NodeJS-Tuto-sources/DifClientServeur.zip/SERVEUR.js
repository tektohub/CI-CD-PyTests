var readline = require("readline-sync");

var messageMenu = "Choissisez une option :\n";
messageMenu += "1 : Liste des clients\n";
messageMenu += "2 : Ajouter un client\n";
messageMenu += "3 : Quitter \n";
messageMenu += "Quel est votre choix ? : ";
var saisie = readline.question(messageMenu);

console.log("Le choix de l'utilisateur est "+saisie);